﻿using IManager.Shared;
using System;
using System.Collections.Generic;
using System.Text;

namespace Manager.Implementation
{
    public class ManagerImplementation:IManagerShared
    {
    }
}

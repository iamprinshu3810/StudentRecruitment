﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IManager.Shared
{
    public class IManagerShared
    {
    }
}

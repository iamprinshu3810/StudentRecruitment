﻿using IManager.Shared;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentRecruitmentTest.Controllers
{
    public class UserController : Controller
    {
        private readonly IManagerShared _manager;
        public UserController(IManagerShared manager)
        {
            _manager = manager;
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}

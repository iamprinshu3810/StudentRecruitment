﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IRepository.Shared
{
    public class IRepositoryShared
    {
    }
}

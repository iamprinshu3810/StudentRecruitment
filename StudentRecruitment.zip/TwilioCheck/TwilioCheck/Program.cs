﻿using System;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace TwilioCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            string accountSid = Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID");
            string authToken = Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN");

            TwilioClient.Init(accountSid, authToken);

            var message = MessageResource.Create(
                body: "This is the ship that made the Kessel Run in fourteen parsecs?",
                from: new Twilio.Types.PhoneNumber("+14803866291"),
                to: new Twilio.Types.PhoneNumber("+918800861697")
            );

            Console.WriteLine(message.Sid);
        }
    }
}

